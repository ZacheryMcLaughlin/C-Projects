#include "Monkey.h"

/***********************************************************************************
**Function: Monkey
**Description: Constructor that initializes the variables
**Parameters: N/A
**Pre-Condition: N/A
**Post-Conditions: N/A
************************************************************************************/
Monkey::Monkey(){
    age = 104;
    cost = 15000;
    babies = 1;
}


