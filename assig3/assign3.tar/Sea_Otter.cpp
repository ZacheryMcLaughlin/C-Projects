#include "Sea_Otter.h"

/***********************************************************************************
**Function: Sea Otter
**Description: Constructor that initializes the variables
**Parameters: N/A
**Pre-Condition: N/A
**Post-Conditions: N/A
************************************************************************************/
Sea_Otter::Sea_Otter(){
    age = 104;
    cost = 5000;
    babies = 2;

}