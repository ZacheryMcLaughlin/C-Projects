#ifndef SEA_OTTER_H
#define SEA_OTTER_H

#include "Animal.h"

class Sea_Otter : public Animal {
    private:

    public:
        Sea_Otter();
};
#endif