#ifndef MONKEY_H
#define MONKEY_H

#include "Animal.h"

class Monkey : public Animal{
    private:

    public:
        Monkey();
};
#endif