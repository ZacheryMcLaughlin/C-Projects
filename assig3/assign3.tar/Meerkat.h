#ifndef MEERKAT_H
#define MEERKAT_H

#include "Animal.h"

class Meerkat : public Animal {
    private:

    public:
        Meerkat();
};
#endif