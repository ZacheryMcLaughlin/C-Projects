#include "Meerkat.h"

/***********************************************************************************
**Function: Meerkat
**Description: Constructor that initializes the variables
**Parameters: N/A
**Pre-Condition: N/A
**Post-Conditions: N/A
************************************************************************************/
Meerkat::Meerkat(){
    age = 104;
    cost = 500;
    babies = 5;
}